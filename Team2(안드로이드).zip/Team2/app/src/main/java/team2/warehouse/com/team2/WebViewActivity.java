package team2.warehouse.com.team2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import org.apache.http.util.EncodingUtils;

public class WebViewActivity extends Activity {

    private WebView mWebView; //웹뷰
    private WebSettings mWebSettings; //웹뷰세팅

    String email;
    boolean admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        email = getIntent().getStringExtra("email");
        admin = getIntent().getBooleanExtra("admin",false);
        String show = getIntent().getStringExtra("show");
        String category = getIntent().getStringExtra("category");
        int index = getIntent().getIntExtra("index",0); //기본값 -1로 바꾸고 -1일때 finish()나 back()해버리기

        // 웹뷰 세팅
        mWebView = findViewById(R.id.webview); //레이어와 연결
        mWebView .setWebViewClient(new WebViewClient()); // 클릭시 새창 안뜨게
        mWebSettings = mWebView.getSettings(); //세부 세팅 등록
        mWebSettings.setJavaScriptEnabled(true); // 자바스크립트 사용 허용

        String url=""; //연결하고자 하는 URL 주소 입력
        String postData = ""; //파라미터 입력

        if(show.equals("extend")) { //연장 페이지
            postData = "email=" + email + "&category=" + category + "&index=" +index;
            if (admin)
                url = "http://itwillbs2.cafe24.com/Team2/and/admin_extend";
            else
                url = "http://itwillbs2.cafe24.com/Team2/and/extend";
        }else if(show.equals("out")) { //보관 빼기
            postData = "result=" + getIntent().getStringExtra("result");
            url = "http://itwillbs2.cafe24.com/Team2/and/admin_release_check";
        }else if(show.equals("in")) { //예약 -> 창고 넣기 전 확인
            postData = "result=" + getIntent().getStringExtra("result");
            url = "http://itwillbs2.cafe24.com/Team2/and/admin_warehousing_check";
        }

        mWebView.postUrl(url,EncodingUtils.getBytes(postData, "BASE64"));
    }
}
