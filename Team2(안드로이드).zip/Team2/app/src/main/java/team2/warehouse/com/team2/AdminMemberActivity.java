package team2.warehouse.com.team2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AdminMemberActivity extends Activity {

    String email;
    String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_member);
        email = getIntent().getStringExtra("email");

        NetworkTask networkTask = new NetworkTask("http://itwillbs2.cafe24.com/Team2/and/admin_member", null);
        networkTask.execute();

    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        String url;
        ContentValues values;

        NetworkTask(String url, ContentValues values) {
            this.url = url;
            this.values = values;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progress bar를 보여주는 등등의 행위
        }

        @Override
        protected String doInBackground(Void... params) {
            String result;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result; // 결과가 여기에 담깁니다. 아래 onPostExecute()의 파라미터로 전달됩니다.
        }

        @Override
        protected void onPostExecute(String result) {
            // 통신이 완료되면 호출됩니다.
            // 결과에 따른 UI 수정 등은 여기서 합니다.

            /* Find Tablelayout defined in main.xml */
            TableLayout tl = (TableLayout) findViewById(R.id.member_table);

            try {
                JSONArray jList = new JSONArray(result);

                for (int i = 0; i < jList.length(); i++) {
                    JSONObject obj = jList.getJSONObject(i);
                    String admin = obj.getString("admin");
                    if (admin.equals("1"))
                        admin = "관리자";
                    else admin = "회원";
                    String name = obj.getString("name");
                    String email = obj.getString("email");

                    /* Create a new row to be added. */
                    final TableRow tr = new TableRow(AdminMemberActivity.this);
                    tr.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
                    tr.setBackgroundResource(R.drawable.table_border);
                    tr.setId(i);
                    /* Create a Button to be the row-content. */
                    TextView flagTv = new TextView(AdminMemberActivity.this);
                    flagTv.setText(admin);
                    flagTv.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));
                    flagTv.setGravity(Gravity.CENTER);
                    flagTv.setPadding(5, 20, 5, 20);
                    flagTv.setTextSize(15);
                    flagTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(flagTv);

                    TextView nameTv = new TextView(AdminMemberActivity.this);
                    nameTv.setText(name);
                    nameTv.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));
                    nameTv.setGravity(Gravity.CENTER);
                    nameTv.setPadding(5, 20, 5, 20);
                    nameTv.setTextSize(15);
                    nameTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(nameTv);

                    TextView emailTv = new TextView(AdminMemberActivity.this);
                    emailTv.setText(email);
                    emailTv.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1));
                    emailTv.setGravity(Gravity.CENTER);
                    emailTv.setPadding(5, 20, 5, 20);
                    emailTv.setTextSize(15);
                    emailTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(emailTv);

                    /* Add row to TableLayout. */
                    tl.addView(tr, new TableLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

                    final String list = result;
                    tr.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog.Builder alert = new AlertDialog.Builder(AdminMemberActivity.this);
                            try {
                                JSONArray jList = new JSONArray(list);
                                JSONObject obj = jList.getJSONObject(tr.getId());
                                String admin = obj.getString("admin");
                                if (admin.equals("1"))
                                    admin = "관리자";
                                else admin = "회원";

                                alert.setTitle(admin + " " + obj.getString("name") + "님의 상세 정보");
                                alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();     //닫기
                                    }
                                });
                                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                                Date date = format.parse(obj.getString("reg_date"));
                                SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd a hh:ss");
                                String reg_date = format2.format(date);

                                String msg = "";
                                msg = "이메일: " + obj.getString("email") + "\n연락처: " + obj.getString("phone") + "\n우편: " + obj.getString("postCode")
                                        + "\n주소: " + obj.getString("roadAddr") + "\n상세주소: " + obj.getString("detailAddr") + "\n가입일: " + reg_date;
                                alert.setMessage(msg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            alert.show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

