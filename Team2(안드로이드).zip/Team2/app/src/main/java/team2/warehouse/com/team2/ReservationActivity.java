package team2.warehouse.com.team2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class ReservationActivity extends Activity {

    String email;
    String category;
    TableLayout tl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);
        email = getIntent().getStringExtra("email");
        category = getIntent().getStringExtra("category");

        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("category", category);

        NetworkTask networkTask = new NetworkTask("http://itwillbs2.cafe24.com/Team2/and/status", values);
        networkTask.execute();

    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        String url;
        ContentValues values;

        NetworkTask(String url, ContentValues values) {
            this.url = url;
            this.values = values;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progress bar를 보여주는 등등의 행위
        }

        @Override
        protected String doInBackground(Void... params) {
            String result;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result; // 결과가 여기에 담깁니다. 아래 onPostExecute()의 파라미터로 전달됩니다.
        }

        @Override
        protected void onPostExecute(String result) {
            // 통신이 완료되면 호출됩니다.
            // 결과에 따른 UI 수정 등은 여기서 합니다.

            /* Find Tablelayout defined in main.xml */
            tl = (TableLayout) findViewById(R.id.reserv_table);

            try {
                JSONArray jList = new JSONArray(result);

                for (int i = 0; i < jList.length(); i++) {
                    JSONObject obj = jList.getJSONObject(i);
                    String house = obj.getString("house");
                    String res_day = obj.getString("res_day");
                    String start_day = obj.getString("start_day");

                    /* Create a new row to be added. */
                    final TableRow tr = new TableRow(ReservationActivity.this);
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tr.setBackgroundColor(Color.BLACK);
                    //tr.setMinimumHeight(100);
                    tr.setId(i);
                    /* Create a Button to be the row-content. */
                    TextView houseTv = new TextView(ReservationActivity.this);
                    houseTv.setText(house);
                    houseTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    houseTv.setGravity(Gravity.CENTER);
                    houseTv.setPadding(5, 20, 5, 20);
                    houseTv.setTextSize(15);
                    houseTv.setBackgroundColor(Color.WHITE);
                    houseTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(houseTv);

                    TextView reservTv = new TextView(ReservationActivity.this);
                    reservTv.setText(res_day);
                    reservTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    reservTv.setGravity(Gravity.CENTER);
                    reservTv.setPadding(5, 20, 5, 20);
                    reservTv.setTextSize(15);
                    reservTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(reservTv);

                    TextView startTv = new TextView(ReservationActivity.this);
                    startTv.setText(start_day);
                    startTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    startTv.setGravity(Gravity.CENTER);
                    startTv.setPadding(5, 20, 5, 20);
                    startTv.setTextSize(15);
                    startTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(startTv);

                    /* Add row to TableLayout. */
                    tl.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    final String list = result;
                    tr.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog.Builder alert = new AlertDialog.Builder(ReservationActivity.this);
                            try {
                                JSONArray jList = new JSONArray(list);
                                JSONObject obj = jList.getJSONObject(tr.getId());

                                alert.setTitle("창고번호 " + obj.getString("house") + "의\n예약을 연장하시겠습니까?");
                                alert.setPositiveButton("연장하기", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent browse = new Intent(getApplicationContext(), WebViewActivity.class);
                                        browse.putExtra("email",email);
                                        browse.putExtra("show","extend");
                                        browse.putExtra("category",category);
                                        browse.putExtra("index",tr.getId());
                                        startActivity(browse);
                                    }
                                }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                                String msg = "";

                                msg = "창고번호: " + obj.getString("house") + "\n예약일: " + obj.getString("res_day") + "\n시작일: " + obj.getString("start_day")
                                        + "\n종료일: " + obj.getString("end_day") + "\n이용금액: " + obj.getString("payment") + "원";
                                alert.setMessage(msg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            alert.show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
