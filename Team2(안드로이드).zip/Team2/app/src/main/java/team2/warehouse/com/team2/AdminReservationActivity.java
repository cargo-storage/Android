package team2.warehouse.com.team2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class AdminReservationActivity extends Activity {

    String email;
    String category;
    TableLayout tl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_reservation);
        email=getIntent().getStringExtra("email");
        category = getIntent().getStringExtra("category");

        ContentValues values = new ContentValues();
        values.put("category", category);

        NetworkTask networkTask = new NetworkTask("http://itwillbs2.cafe24.com/Team2/and/admin_status", values);
        networkTask.execute();

    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        String url;
        ContentValues values;

        NetworkTask(String url, ContentValues values) {
            this.url = url;
            this.values = values;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progress bar를 보여주는 등등의 행위
        }

        @Override
        protected String doInBackground(Void... params) {
            String result;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result; // 결과가 여기에 담깁니다. 아래 onPostExecute()의 파라미터로 전달됩니다.
        }

        @Override
        protected void onPostExecute(String result) {
            // 통신이 완료되면 호출됩니다.
            // 결과에 따른 UI 수정 등은 여기서 합니다.

            /* Find Tablelayout defined in main.xml */
            tl = (TableLayout) findViewById(R.id.reserv_table);

            try {
                JSONArray jList = new JSONArray(result);

                for (int i = 0; i < jList.length(); i++) {
                    JSONObject obj = jList.getJSONObject(i);
                    String name = obj.getString("name");
                    String email2 = obj.getString("email");
                    String house = obj.getString("house");
                    String res_day = obj.getString("res_day");

                    /* Create a new row to be added. */
                    final TableRow tr = new TableRow(AdminReservationActivity.this);
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tr.setBackgroundResource(R.drawable.table_border);
                    tr.setId(i);
                    /* Create a Button to be the row-content. */
                    TextView nameTv = new TextView(AdminReservationActivity.this);
                    nameTv.setText(name);
                    nameTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    nameTv.setGravity(Gravity.CENTER);
                    nameTv.setPadding(5, 20, 5, 20);
                    nameTv.setTextSize(15);
                    nameTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(nameTv);

                    TextView emailTv = new TextView(AdminReservationActivity.this);
                    emailTv.setText(email2); //각 각의 이메일
                    emailTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    emailTv.setGravity(Gravity.CENTER);
                    emailTv.setPadding(5, 20, 5, 20);
                    emailTv.setTextSize(15);
                    emailTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(emailTv);

                    TextView houseTv = new TextView(AdminReservationActivity.this);
                    houseTv.setText(house);
                    houseTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 0));
                    houseTv.setGravity(Gravity.CENTER);
                    houseTv.setPadding(5, 20, 5, 20);
                    houseTv.setTextSize(15);
                    houseTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(houseTv);

                    TextView reservTv = new TextView(AdminReservationActivity.this);
                    reservTv.setText(res_day);
                    reservTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    reservTv.setGravity(Gravity.CENTER);
                    reservTv.setPadding(5, 20, 5, 20);
                    reservTv.setTextSize(15);
                    reservTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(reservTv);

                    /* Add row to TableLayout. */
                    tl.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    final String list = result;
                    tr.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog.Builder alert = new AlertDialog.Builder(AdminReservationActivity.this);
                            try {
                                JSONArray jList = new JSONArray(list);
                                JSONObject obj = jList.getJSONObject(tr.getId());
                                final String jStr = obj.toString();

                                alert.setTitle(obj.getString("name")+"님의\n창고번호 " + obj.getString("house") + "의 예약 정보");
                                alert.setPositiveButton("예약 연장하기", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent browse = new Intent(getApplicationContext(), WebViewActivity.class);
                                        browse.putExtra("email",email); //관리자로 로그인 시켜야하기 때문에 관리자 이메일
                                        browse.putExtra("admin",true);
                                        browse.putExtra("show", "extend"); // 연장
                                        browse.putExtra("category",category); //category = reservation
                                        browse.putExtra("index",tr.getId());
                                        startActivity(browse);
                                    }
                                }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                }).setNeutralButton("창고에 넣기", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent browse = new Intent(getApplicationContext(), WebViewActivity.class);
                                        browse.putExtra("result",jStr);
                                        browse.putExtra("admin",true);
                                        browse.putExtra("show", "in");
                                        startActivity(browse);
                                    }
                                });
                                String msg = "";

                                msg = "========== 예약 정보 ==========\n";
                                msg += "창고번호: " + obj.getString("house") + "\n예약일: " + obj.getString("res_day") + "\n시작일: " + obj.getString("start_day")
                                        + "\n종료일: " + obj.getString("end_day") + "\n보관비용: " + obj.getString("payment") + "원";
                                msg += "\n\n========== 고객 정보 ==========\n";
                                msg += "이름: " + obj.getString("name") + "\n이메일: " + obj.getString("email")
                                        + "\n전화번호: " + obj.getString("phone");
                                alert.setMessage(msg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            alert.show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
