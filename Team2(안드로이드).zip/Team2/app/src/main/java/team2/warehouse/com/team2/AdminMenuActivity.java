package team2.warehouse.com.team2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminMenuActivity extends Activity implements Button.OnClickListener {

    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        email = getIntent().getStringExtra("email");

        Button stor_btn = findViewById(R.id.stor_btn);
        stor_btn.setOnClickListener(this);
        Button reserv_btn = findViewById(R.id.reserv_btn);
        reserv_btn.setOnClickListener(this);
        Button finish_btn = findViewById(R.id.finish_btn);
        finish_btn.setOnClickListener(this);
        Button member_btn = findViewById(R.id.member_btn);
        member_btn.setOnClickListener(this);

    }

    // Button.OnclickListener를 implements하므로 onClick() 함수를 오버라이딩.
    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.stor_btn:
                intent = new Intent(getApplicationContext(), AdminHouseStatusActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("category", "items");
                startActivity(intent);
                break;
            case R.id.reserv_btn:
                intent = new Intent(getApplicationContext(), AdminReservationActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("category", "reservation");
                startActivity(intent);
                break;
            case R.id.finish_btn:
                intent = new Intent(getApplicationContext(), AdminClosedActivity.class);
                intent.putExtra("category", "closed");
                startActivity(intent);
                break;
            case R.id.member_btn:
                intent = new Intent(getApplicationContext(), AdminMemberActivity.class);
                startActivity(intent);
                break;
        }
    }
}

