package team2.warehouse.com.team2;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
public class MainActivity extends AppCompatActivity {

    EditText edt_email;
    EditText edt_pwd;
    String email;
    String pwd;


    @Override
    protected void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.activity_main);

        Button login_btn = findViewById(R.id.login_btn);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt_email = findViewById(R.id.email);
                edt_pwd = findViewById(R.id.pwd);
                email = edt_email.getText().toString();
                pwd = edt_pwd.getText().toString();

                ContentValues values = new ContentValues();
                values.put("email", email);
                values.put("pwd", pwd);

                NetworkTask networkTask = new NetworkTask("http://itwillbs2.cafe24.com/Team2/and/login", values);
                networkTask.execute();
            }
        });
    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        String url;
        ContentValues values;

        NetworkTask(String url, ContentValues values) {
            this.url = url;
            this.values = values;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progress bar를 보여주는 등등의 행위
        }

        @Override
        protected String doInBackground(Void... params) {
            String result;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result; // 결과가 여기에 담깁니다. 아래 onPostExecute()의 파라미터로 전달됩니다.
        }

        @Override
        protected void onPostExecute(String result) {
            // 통신이 완료되면 호출됩니다.
            // 결과에 따른 UI 수정 등은 여기서 합니다.
            if (result.equals("1")||result.equals("4")) {
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                if(result.equals("4"))
                    intent.putExtra("admin", true);
                intent.putExtra("email", email);
                startActivity(intent);
                finish();
            } else if (result.equals("-1")) {
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("비밀번호 오류");
                alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();     //닫기
                    }
                });
                alert.setMessage("비밀번호가 틀립니다. \n확인 후 다시 로그인 해 주세요.");
                alert.show();
            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("이메일 오류");
                alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();     //닫기
                    }
                });
                alert.setMessage("등록된 이메일이 없습니다. \n확인 후 다시 로그인 해 주세요.");
                alert.show();
            }
        }
    }
}



