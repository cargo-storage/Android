package team2.warehouse.com.team2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class AdminClosedActivity extends Activity {

    String email;
    String category;
    TableLayout tl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_closed);
        category = getIntent().getStringExtra("category");

        ContentValues values = new ContentValues();
        values.put("category", category);

        NetworkTask networkTask = new NetworkTask("http://itwillbs2.cafe24.com/Team2/and/admin_status", values);
        networkTask.execute();

    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        String url;
        ContentValues values;

        NetworkTask(String url, ContentValues values) {
            this.url = url;
            this.values = values;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //progress bar를 보여주는 등등의 행위
        }

        @Override
        protected String doInBackground(Void... params) {
            String result;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result; // 결과가 여기에 담깁니다. 아래 onPostExecute()의 파라미터로 전달됩니다.
        }

        @Override
        protected void onPostExecute(String result) {
            // 통신이 완료되면 호출됩니다.
            // 결과에 따른 UI 수정 등은 여기서 합니다.

            /* Find Tablelayout defined in main.xml */
            tl = (TableLayout) findViewById(R.id.closed_table);

            try {
                JSONArray jList = new JSONArray(result);

                for (int i = 0; i < jList.length(); i++) {
                    JSONObject obj = jList.getJSONObject(i);
                    String m_email = obj.getString("email"); //회원 이메일
                    String item = obj.getString("item");
                    String start_day = obj.getString("start_day");
                    String return_day = obj.getString("return_day");

                    /* Create a new row to be added. */
                    final TableRow tr = new TableRow(AdminClosedActivity.this);
                    tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                    tr.setBackgroundResource(R.drawable.table_border);
                    tr.setId(i);
                    /* Create a Button to be the row-content. */
                    TextView emailTv = new TextView(AdminClosedActivity.this);
                    emailTv.setText(m_email);
                    emailTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    emailTv.setGravity(Gravity.CENTER);
                    emailTv.setPadding(5, 20, 5, 20);
                    emailTv.setTextSize(15);
                    emailTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(emailTv);

                    TextView itemTv = new TextView(AdminClosedActivity.this);
                    itemTv.setText(item);
                    itemTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    itemTv.setGravity(Gravity.CENTER);
                    itemTv.setPadding(5, 20, 5, 20);
                    itemTv.setTextSize(15);
                    itemTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(itemTv);

                    TextView startTv = new TextView(AdminClosedActivity.this);
                    startTv.setText(start_day);
                    startTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    startTv.setGravity(Gravity.CENTER);
                    startTv.setPadding(5, 20, 5, 20);
                    startTv.setTextSize(15);
                    startTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(startTv);

                    TextView returnTv = new TextView(AdminClosedActivity.this);
                    returnTv.setText(return_day);
                    returnTv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));
                    returnTv.setGravity(Gravity.CENTER);
                    returnTv.setPadding(5, 20, 5, 20);
                    returnTv.setTextSize(15);
                    returnTv.setBackgroundResource(R.drawable.table_border);
                    tr.addView(returnTv);

                    /* Add row to TableLayout. */
                    tl.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT));

                    final String list = result;
                    tr.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            AlertDialog.Builder alert = new AlertDialog.Builder(AdminClosedActivity.this);
                            try {
                                JSONArray jList = new JSONArray(list);
                                JSONObject obj = jList.getJSONObject(tr.getId());
                                final String jStr = obj.toString();

                                alert.setTitle(obj.getString("name")+"님의\n" + obj.getString("item") + " 완료 상세 정보");
                                alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                                String msg = "";

                                msg = "========== 완료 정보 ==========\n";
                                msg += "창고번호: " + obj.getString("house") + "\n시작일: " + obj.getString("start_day")
                                        + "\n종료일: " + obj.getString("end_day") + "\n실수령일: " + obj.getString("return_day")
                                        + "\n이용금액: " + obj.getString("payment") + "원" + "\n상품가치: " + obj.getString("item_price") + "원";
                                msg += "\n\n========== 고객 정보 ==========\n";
                                msg += "이름: " + obj.getString("name") + "\n이메일: " + obj.getString("email")
                                        + "\n전화번호: " + obj.getString("phone");
                                alert.setMessage(msg);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            alert.show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
