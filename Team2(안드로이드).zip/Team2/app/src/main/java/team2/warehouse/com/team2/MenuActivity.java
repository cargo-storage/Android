package team2.warehouse.com.team2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MenuActivity extends Activity implements Button.OnClickListener {

    String email;
    Boolean admin;
    Button manager_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        email = getIntent().getStringExtra("email");
        admin = getIntent().getBooleanExtra("admin",false);

        Button stor_btn = findViewById(R.id.stor_btn);
        stor_btn.setOnClickListener(this);
        Button reserv_btn = findViewById(R.id.reserv_btn);
        reserv_btn.setOnClickListener(this);

        if(admin){
            manager_btn = (Button)findViewById(R.id.manager_btn);

            manager_btn.setVisibility(View.VISIBLE);

            manager_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(), AdminMenuActivity.class);
                    intent.putExtra("email", email);
                    startActivity(intent);
                }
            });
        }
    }

    // Button.OnclickListener를 implements하므로 onClick() 함수를 오버라이딩.
    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.stor_btn:
                intent = new Intent(getApplicationContext(), StatusActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("category", "status");
                startActivity(intent);
                break;
            case R.id.reserv_btn:
                intent = new Intent(getApplicationContext(), ReservationActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("category", "reservation");
                startActivity(intent);
                break;
        }
    }
}