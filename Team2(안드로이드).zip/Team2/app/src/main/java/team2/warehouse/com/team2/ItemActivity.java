package team2.warehouse.com.team2;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothState;
import app.akexorcist.bluetotohspp.library.DeviceList;

public class ItemActivity extends Activity {

    int index;
    String result;
    private BluetoothSPP bt;
    int count = 0;
    TextView textResult;
    TextView textResult2;
    Button btnExtend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        bt = new BluetoothSPP(this); //Initializing

        textResult2 = findViewById(R.id.TextResult2);
        textResult = findViewById(R.id.TextResult);

        if (!bt.isBluetoothAvailable()) { //블루투스 사용 불가
            Toast.makeText(getApplicationContext()
                    , "Bluetooth is not available"
                    , Toast.LENGTH_SHORT).show();
            finish();
        }

        index = getIntent().getIntExtra("index", -1);
        result = getIntent().getStringExtra("result");

        if (index == -1) {
            AlertDialog.Builder alert = new AlertDialog.Builder(ItemActivity.this);
            alert.setTitle("시스템 오류");
            alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();     //닫기
                }
            });
            alert.setMessage("시스템 오류가 발생했습니다.\n다시 시도해주세요.");
            alert.show();
            finish();
        }

        LinearLayout house_info_layout = findViewById(R.id.house_info_layout);

        try {
            JSONArray jList = new JSONArray(result);
            JSONObject obj = jList.getJSONObject(index);

            String state = obj.getString("state");
            String item = obj.getString("item");
            String house = obj.getString("house");
            String start_day = obj.getString("start_day");
            String end_day = obj.getString("end_day");
            String payment = obj.getString("payment");
            String item_price = obj.getString("item_price");

            TextView stateTv = new TextView(ItemActivity.this);
            stateTv.setText("상태: " + state);
            stateTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            stateTv.setTextSize(20);
            stateTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(stateTv);

            TextView itemTv = new TextView(ItemActivity.this);
            itemTv.setText("물품ID: " + item);
            itemTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            itemTv.setTextSize(20);
            itemTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(itemTv);

            TextView houseTv = new TextView(ItemActivity.this);
            houseTv.setText("창고번호: " + house);
            houseTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            houseTv.setTextSize(20);
            houseTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(houseTv);

            TextView start_dayTv = new TextView(ItemActivity.this);
            start_dayTv.setText("시작일: " + start_day);
            start_dayTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            start_dayTv.setTextSize(20);
            start_dayTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(start_dayTv);


            TextView end_dayTv = new TextView(ItemActivity.this);
            end_dayTv.setText("종료일: " + end_day);
            end_dayTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            end_dayTv.setTextSize(20);
            end_dayTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(end_dayTv);

            TextView paymentTv = new TextView(ItemActivity.this);
            paymentTv.setText("이용금액: " + payment+"원");
            paymentTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            paymentTv.setTextSize(20);
            paymentTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(paymentTv);

            TextView item_priceTv = new TextView(ItemActivity.this);
            item_priceTv.setText("상품가치: " + item_price+"원");
            item_priceTv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            item_priceTv.setTextSize(20);
            item_priceTv.setGravity(Gravity.CENTER);
            house_info_layout.addView(item_priceTv);

        } catch (Exception e) {
            e.printStackTrace();
        }

        bt.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener() { //데이터 수신
            public void onDataReceived(byte[] data, String message) {
                count++;
                if (count / 2 == 0)
                    textResult.setText("온도 : " + message.toString());
                else
                    textResult2.setText("습도 : " + message.toString());
                //Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        bt.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener() { //연결됐을 때
            public void onDeviceConnected(String name, String address) {
                Toast.makeText(getApplicationContext()
                        , "Connected to " + name + "\n" + address
                        , Toast.LENGTH_SHORT).show();

                btnExtend = findViewById(R.id.btnExtend);
                btnExtend.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            JSONArray jList = new JSONArray(result);
                            JSONObject obj = jList.getJSONObject(index);
                            Intent browse = new Intent(getApplicationContext(), WebViewActivity.class);
                            browse.putExtra("email", obj.getString("email")); //유저 이메일 (안 보내면 ExtendActivity에러남)
                            browse.putExtra("show", "extend"); //연장
                            browse.putExtra("category", "status"); //category = status
                            browse.putExtra("index", index);
                            startActivity(browse);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            public void onDeviceDisconnected() { //연결해제
                Toast.makeText(getApplicationContext()
                        , "Connection lost", Toast.LENGTH_SHORT).show();
            }

            public void onDeviceConnectionFailed() { //연결실패
                Toast.makeText(getApplicationContext()
                        , "Unable to connect", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnConnect = findViewById(R.id.btnConnect); //연결시도
        btnConnect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (bt.getServiceState() == BluetoothState.STATE_CONNECTED) {
                    bt.disconnect();
                } else {
                    Intent intent = new Intent(getApplicationContext(), DeviceList.class);
                    startActivityForResult(intent, BluetoothState.REQUEST_CONNECT_DEVICE);
                }
            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        bt.stopService(); //블루투스 중지
    }

    public void onStart() {
        super.onStart();
        if (!bt.isBluetoothEnabled()) { //
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, BluetoothState.REQUEST_ENABLE_BT);
        } else {
            if (!bt.isServiceAvailable()) {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER); //DEVICE_ANDROID는 안드로이드 기기 끼리
                setup();
            }
        }
    }

    public void setup() {
        Button btnSend = findViewById(R.id.btnExtend); //데이터 전송
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                bt.send("Text", true);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE) {
            if (resultCode == Activity.RESULT_OK)
                bt.connect(data);
        } else if (requestCode == BluetoothState.REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER);
                setup();
            } else {
                Toast.makeText(getApplicationContext()
                        , "Bluetooth was not enabled."
                        , Toast.LENGTH_SHORT).show();
                finish();
            }
        }


    }
}


